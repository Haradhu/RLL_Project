import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentlogout',
  templateUrl: './studentlogout.component.html',
  styleUrls: ['./studentlogout.component.css']
})
export class StudentlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
