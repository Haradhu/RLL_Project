export class PackageDetails
{
    pid:number;
    pname:string;
    pstartingdate:Date;
    pstudentattendance:string;
    pvehicle:string;
    ptrainername:string;
    ptrainerlocation:string;
    ptrainerexp:number;
}