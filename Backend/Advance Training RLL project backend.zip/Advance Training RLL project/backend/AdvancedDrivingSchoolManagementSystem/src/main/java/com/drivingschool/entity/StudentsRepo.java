package com.drivingschool.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentsRepo extends JpaRepository<Students, Integer> {

	@Query(value=("select * from students where students.Sname= ? "), nativeQuery = true)
	public Students searchStudent(String sname);
}
