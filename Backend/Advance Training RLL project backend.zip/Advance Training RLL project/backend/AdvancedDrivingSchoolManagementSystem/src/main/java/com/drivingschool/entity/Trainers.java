package com.drivingschool.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Trainers implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Tid;
	private String Tname;
	private String Temail;
	private String Tlocation;
	
	public Trainers() {
	
	}

	public Trainers(int tid, String tname, String temail, String tlocation) {
		super();
		Tid = tid;
		Tname = tname;
		Temail = temail;
		Tlocation = tlocation;
	}

	public int getTid() {
		return Tid;
	}

	public void setTid(int tid) {
		Tid = tid;
	}

	public String getTname() {
		return Tname;
	}

	public void setTname(String tname) {
		Tname = tname;
	}

	public String getTemail() {
		return Temail;
	}

	public void setTemail(String temail) {
		Temail = temail;
	}

	public String getTlocation() {
		return Tlocation;
	}

	public void setTlocation(String tlocation) {
		Tlocation = tlocation;
	}
	
}
