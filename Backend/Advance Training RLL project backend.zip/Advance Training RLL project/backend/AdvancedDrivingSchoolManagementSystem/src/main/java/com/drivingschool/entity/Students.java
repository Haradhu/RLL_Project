package com.drivingschool.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Students implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Sid;
	private String Sname;
	private String Sage;
	private String Semail;
	private String Spassword;
	private String Slocation;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Pid")
	private PackageDetails Pdetails;

	public Students() {

	}

	public Students(int sid, String sname, String sage, String semail, String spassword, String slocation,
			PackageDetails pdetails) {
		
		Sid = sid;
		Sname = sname;
		Sage = sage;
		Semail = semail;
		Spassword = spassword;
		Slocation = slocation;
		Pdetails = pdetails;
	}

	public int getSid() {
		return Sid;
	}

	public void setSid(int sid) {
		Sid = sid;
	}

	public String getSname() {
		return Sname;
	}

	public void setSname(String sname) {
		Sname = sname;
	}

	public String getSage() {
		return Sage;
	}

	public void setSage(String sage) {
		Sage = sage;
	}

	public String getSemail() {
		return Semail;
	}

	public void setSemail(String semail) {
		Semail = semail;
	}

	public String getSpassword() {
		return Spassword;
	}

	public void setSpassword(String spassword) {
		Spassword = spassword;
	}

	public String getSlocation() {
		return Slocation;
	}

	public void setSlocation(String slocation) {
		Slocation = slocation;
	}

	public PackageDetails getPdetails() {
		return Pdetails;
	}

	public void setPdetails(PackageDetails pdetails) {
		Pdetails = pdetails;
	}

	
}
