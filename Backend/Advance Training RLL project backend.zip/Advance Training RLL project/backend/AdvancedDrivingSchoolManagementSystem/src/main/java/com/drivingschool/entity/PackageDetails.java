package com.drivingschool.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class PackageDetails implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Pid;
	private String Pname;
	@JsonFormat(pattern="dd/MM/yyyy")
	private Date Pstartingdate;
	private String Pstudentattendance;
	private String Pvehicle;
	private String Ptrainername;
	private String Ptrainerlocation;
	private int Ptrainerexp;
	
	@OneToMany(mappedBy = "Pdetails")
	private List<Students> students = new ArrayList<>();

	public PackageDetails() {
		
	}

	public PackageDetails(int pid, String pname, Date pstartingdate, String pstudentattendance, String pvehicle,
			String ptrainername, String ptrainerlocation, int ptrainerexp, List<Students> students) {
		super();
		Pid = pid;
		Pname = pname;
		Pstartingdate = pstartingdate;
		Pstudentattendance = pstudentattendance;
		Pvehicle = pvehicle;
		Ptrainername = ptrainername;
		Ptrainerlocation = ptrainerlocation;
		Ptrainerexp = ptrainerexp;
		this.students = students;
	}

	public int getPid() {
		return Pid;
	}

	public void setPid(int pid) {
		Pid = pid;
	}

	public String getPname() {
		return Pname;
	}

	public void setPname(String pname) {
		Pname = pname;
	}

	public Date getPstartingdate() {
		return Pstartingdate;
	}

	public void setPstartingdate(Date pstartingdate) {
		Pstartingdate = pstartingdate;
	}

	public String getPstudentattendance() {
		return Pstudentattendance;
	}

	public void setPstudentattendance(String pstudentattendance) {
		Pstudentattendance = pstudentattendance;
	}

	public String getPvehicle() {
		return Pvehicle;
	}

	public void setPvehicle(String pvehicle) {
		Pvehicle = pvehicle;
	}

	public String getPtrainername() {
		return Ptrainername;
	}

	public void setPtrainername(String ptrainername) {
		Ptrainername = ptrainername;
	}

	public String getPtrainerlocation() {
		return Ptrainerlocation;
	}

	public void setPtrainerlocation(String ptrainerlocation) {
		Ptrainerlocation = ptrainerlocation;
	}

	public int getPtrainerexp() {
		return Ptrainerexp;
	}

	public void setPtrainerexp(int ptrainerexp) {
		Ptrainerexp = ptrainerexp;
	}

	public List<Students> getStudents() {
		return students;
	}

	public void setStudents(List<Students> students) {
		this.students = students;
	}
	
}
