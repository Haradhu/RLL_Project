package com.drivingschool.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Admin implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Aid;
	private String Aname;
	private String Aemail;
	private String Apassword;
	
	public Admin() {
	
	}

	public Admin(int aid, String aname, String aemail, String apassword) {
		
		Aid = aid;
		Aname = aname;
		Aemail = aemail;
		Apassword = apassword;
	}

	public int getAid() {
		return Aid;
	}

	public void setAid(int aid) {
		Aid = aid;
	}

	public String getAname() {
		return Aname;
	}

	public void setAname(String aname) {
		Aname = aname;
	}

	public String getAemail() {
		return Aemail;
	}

	public void setAemail(String aemail) {
		Aemail = aemail;
	}

	public String getApassword() {
		return Apassword;
	}

	public void setApassword(String apassword) {
		Apassword = apassword;
	}

}
