package com.drivingschool.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drivingschool.entity.Students;
import com.drivingschool.service.StudentsService;


@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/drivingschool")
public class StudentsController {

	@Autowired
	private StudentsService studentsService;
	
	@PostMapping("/student/insert")
	public Students addStudent(@RequestBody Students students)
	{
		return studentsService.addNewStudent(students);
	}
	
	@GetMapping("/student/list")
	public List<Students> listStudents()
	{
		return studentsService.getAllStudents();
	}
	
	@PutMapping("/student/updatepwd")
	public Students updatePwd(@RequestBody Students students)
	{
		return studentsService.updateStudentPwd(students);
	}
	
	@PutMapping("/student/edit")
	public Students updateStudent(@RequestBody Students students)
	{
		return studentsService.updateStudentDetails(students);
	}
	
	@PutMapping("/student/package")
	public Students updateStudentPackage(@RequestBody Students students)
	{
		return studentsService.updateStudentPackageDetails(students);
	}
	
	@PutMapping("/student/remove")
	public void removeStudent(@RequestBody Students students)
	{
		studentsService.removeStudentDetails(students);
	}
	
}
