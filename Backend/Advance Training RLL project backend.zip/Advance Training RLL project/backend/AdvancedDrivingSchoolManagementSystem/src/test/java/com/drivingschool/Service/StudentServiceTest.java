package com.drivingschool.Service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.Spring;

import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.testng.annotations.Test;

import com.drivingschool.entity.Students;
import com.drivingschool.entity.StudentsRepo;
import com.drivingschool.service.StudentsService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentServiceTest {
	
	@Autowired
	private StudentsService studentservice;
	
	@MockBean
	private StudentsRepo srepo;
	
	@BeforeEach
	void setup() {
		
	}
	
	@Test
	public void getAllStudentsTest() {
		when(srepo.findAll()).thenReturn(Stream
				.of( new Students(103, "Srikant", "28", "Srikant.t04@gmail.com", "hh445", "Kolkata", null)).collect(Collectors.toList()));
		assertEquals(1, studentservice.getAllStudents().size());
		
	}
	
	@Test
	public void addnewstudent() {
		Students students = new Students(104, "Raju", "25", "Raju@gmaol.com", "6666dg", "Mumbai", null);
		when(srepo.save(students)).thenReturn(students);
		assertEquals(students, studentservice.addNewStudent(students));
	}
	
	
		
	}

