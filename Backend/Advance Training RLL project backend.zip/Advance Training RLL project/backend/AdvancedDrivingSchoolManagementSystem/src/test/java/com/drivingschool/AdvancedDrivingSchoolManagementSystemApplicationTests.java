package com.drivingschool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedDrivingSchoolManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
