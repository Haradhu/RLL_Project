package com.drivingschool.Service;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.drivingschool.entity.AdminRepo;
import com.drivingschool.service.AdminService;

@ExtendWith(MockitoExtension.class)
public class AdminServiceTest {
	
	@Mock
	private AdminRepo adminrepo;
	
	
	private AdminService adminservice;
	
	@BeforeEach
	void setup() {
		this.adminservice=new AdminService(this.adminrepo);
	}
	
	@Test
	void getAllAdmin() {
		
		adminservice.getAllAdmin();
		verify(adminrepo).findAll();
		
	}

}
