package com.drivingschool.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.testng.annotations.Test;

import com.drivingschool.entity.Admin;
import com.drivingschool.service.AdminService;

@RunWith(MockitoJUnitRunner.class)
public class AdminControllerTest {
	
	@InjectMocks
	private AdminController admincontroller;
	
	@Mock
	private AdminService adminService;
	
	
	@Test
	public void listAdminTest() {
		//give
		List<Admin> admin = new ArrayList<Admin>();
		admin.add(new Admin(109, "Karthik", "karthik88@gmail.com", "99kar56"));
		
		//when //then
		when(adminService.getAllAdmin()).thenReturn(admin);
		
		//assert test
		List<Admin> admin2 = admincontroller.listAdmin();
		assertEquals(1, admin2.size());
		verify(adminService, times(1)).getAllAdmin();
		}
	 
	

}
