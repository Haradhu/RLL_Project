package com.drivingschool.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.testng.annotations.Test;

import com.drivingschool.entity.Students;
import com.drivingschool.service.StudentsService;

@RunWith(MockitoJUnitRunner.class)
public class StudentsControllerTest {
	
	@Mock
	private StudentsService studentsService;
	
	@InjectMocks
	private StudentsController studentscontroller;
	
	
	@Test
	public void addStudentTest() {
		
	}
	
	@Test
	public void listStudentsTest() {
		List<Students> student = new ArrayList<Students>();
		student.add(new Students(112, "Subhodeep", "32", "Subho@gmail.com", "99456", "Kolkata", null));
		
		when(studentsService.getAllStudents()).thenReturn(student);
		
		List<Students> student2 = studentscontroller.listStudents();
		assertEquals(1, student2.size());
		verify(studentsService, times(1)).getAllStudents();
	}

}
